Color Match
===========
A fast 2D color-matching browser game. No backend, no libraries, no login.

How to run
- Open index.html in any modern browser, or upload the whole folder to any static host.

Contents
- index.html  The complete game (HTML + CSS + JavaScript in one file)
- images/     Cover (1200x630) and icon (512x512) in PNG and SVG

Notes
- Best score is saved in the browser with localStorage.
- Share Score uses the Web Share API when available (falls back to copy-to-clipboard).
- All artwork and code are original; no third-party assets.
